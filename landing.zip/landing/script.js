/* =========================================
   BrokerAI Landing Page — Scripts
   ========================================= */

(function () {
  'use strict';

  // ---- Constellation Canvas (Full-screen Hero Background) ----
  function initConstellation() {
    const canvas = document.getElementById('constellation');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let w, h, dpr, particles, mouse;
    const PARTICLE_COUNT = 180;
    const CONNECTION_DISTANCE = 180;
    const MOUSE_RADIUS = 250;

    function resize() {
      dpr = window.devicePixelRatio || 1;
      const rect = canvas.parentElement.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function createParticles() {
      particles = [];
      for (let i = 0; i < PARTICLE_COUNT; i++) {
        const layer = Math.random();
        particles.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * (0.2 + layer * 0.5),
          vy: (Math.random() - 0.5) * (0.2 + layer * 0.5),
          radius: layer < 0.3 ? Math.random() * 1 + 0.5 : layer < 0.7 ? Math.random() * 1.8 + 1 : Math.random() * 2.5 + 1.5,
          opacity: 0.15 + layer * 0.55,
          layer: layer,
        });
      }
    }

    mouse = { x: -1000, y: -1000 };

    document.addEventListener('mousemove', (e) => {
      const rect = canvas.getBoundingClientRect();
      if (e.clientY < rect.bottom) {
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
      } else {
        mouse.x = -1000;
        mouse.y = -1000;
      }
    });

    function draw() {
      ctx.clearRect(0, 0, w, h);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;
        if (p.y < -10) p.y = h + 10;
        if (p.y > h + 10) p.y = -10;

        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const distMouse = Math.sqrt(dx * dx + dy * dy);

        if (distMouse < MOUSE_RADIUS) {
          const force = (MOUSE_RADIUS - distMouse) / MOUSE_RADIUS;
          p.x -= dx * force * 0.025;
          p.y -= dy * force * 0.025;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(96, 165, 250, ${p.opacity})`;
        ctx.fill();

        if (p.radius > 1.5) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius + 4, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(59, 130, 246, ${p.opacity * 0.08})`;
          ctx.fill();
        }

        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const ddx = p.x - p2.x;
          const ddy = p.y - p2.y;
          const dist = Math.sqrt(ddx * ddx + ddy * ddy);

          if (dist < CONNECTION_DISTANCE) {
            const alpha = (1 - dist / CONNECTION_DISTANCE) * 0.2;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = `rgba(59, 130, 246, ${alpha})`;
            ctx.lineWidth = 0.6;
            ctx.stroke();
          }
        }
      }

      if (mouse.x > 0 && mouse.y > 0) {
        let nearCount = 0;
        for (let i = 0; i < particles.length && nearCount < 6; i++) {
          const p = particles[i];
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < MOUSE_RADIUS * 0.8) {
            ctx.beginPath();
            ctx.moveTo(mouse.x, mouse.y);
            ctx.lineTo(p.x, p.y);
            const alpha = (1 - dist / (MOUSE_RADIUS * 0.8)) * 0.12;
            ctx.strokeStyle = `rgba(6, 182, 212, ${alpha})`;
            ctx.lineWidth = 0.4;
            ctx.stroke();
            nearCount++;
          }
        }
      }

      requestAnimationFrame(draw);
    }

    resize();
    createParticles();
    draw();

    let resizeTimeout;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        resize();
        createParticles();
      }, 200);
    });
  }

  // ---- Knowledge Graph Canvas (Bento card — expanded) ----
  function initMiniGraph() {
    const canvas = document.getElementById('miniGraph');
    if (!canvas) return;
    const container = canvas.parentElement;
    const ctx = canvas.getContext('2d');

    let w, h, dpr, mouse;

    function resize() {
      dpr = window.devicePixelRatio || 1;
      const rect = container.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    resize();
    mouse = { x: -1000, y: -1000 };

    container.addEventListener('mousemove', (e) => {
      const rect = container.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
    });
    container.addEventListener('mouseleave', () => {
      mouse.x = -1000;
      mouse.y = -1000;
    });

    const nodes = [
      { bx: 0.42, by: 0.38, r: 14, label: 'João Silva', color: '#3b82f6', type: 'client' },
      { bx: 0.15, by: 0.18, r: 8, label: 'Auto Porto #12345', color: '#06b6d4', type: 'policy' },
      { bx: 0.28, by: 0.12, r: 7, label: 'Vida Bradesco #678', color: '#06b6d4', type: 'policy' },
      { bx: 0.78, by: 0.15, r: 8, label: 'Sinistro vidro', color: '#f87171', type: 'claim' },
      { bx: 0.88, by: 0.35, r: 7, label: 'Sinistro colisão', color: '#f87171', type: 'claim' },
      { bx: 0.08, by: 0.55, r: 6, label: 'Msg curta, noite', color: '#8b5cf6', type: 'pref' },
      { bx: 0.32, by: 0.75, r: 7, label: 'Filho tirou carta', color: '#22c55e', type: 'event' },
      { bx: 0.52, by: 0.85, r: 6, label: 'Mudou de endereço', color: '#22c55e', type: 'event' },
      { bx: 0.75, by: 0.72, r: 7, label: 'Churn: 0.72', color: '#eab308', type: 'score' },
      { bx: 0.90, by: 0.60, r: 6, label: 'Expansão: alto', color: '#eab308', type: 'score' },
      { bx: 0.58, by: 0.18, r: 7, label: 'Recusou 10% desc.', color: '#f59e0b', type: 'negoc' },
      { bx: 0.18, by: 0.82, r: 6, label: 'Porto Seguro', color: '#38bdf8', type: 'insurer' },
      { bx: 0.68, by: 0.52, r: 6, label: 'Renovação ago/26', color: '#a78bfa', type: 'renewal' },
    ];

    const edges = [
      [0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [0, 6], [0, 7],
      [0, 8], [0, 9], [0, 10], [0, 12],
      [1, 11], [1, 12], [2, 10],
      [3, 1], [4, 8],
      [6, 9], [7, 12],
    ];

    let time = 0;
    let hoveredNode = -1;

    function getNodePos(n) {
      return { x: n.bx * w, y: n.by * h };
    }

    function draw() {
      ctx.clearRect(0, 0, w, h);

      hoveredNode = -1;
      for (let i = 0; i < nodes.length; i++) {
        const pos = getNodePos(nodes[i]);
        const dx = mouse.x - pos.x;
        const dy = mouse.y - pos.y;
        if (Math.sqrt(dx * dx + dy * dy) < nodes[i].r + 12) {
          hoveredNode = i;
          break;
        }
      }

      edges.forEach(([a, b], idx) => {
        const pa = getNodePos(nodes[a]);
        const pb = getNodePos(nodes[b]);
        const mx = (pa.x + pb.x) / 2;
        const my = (pa.y + pb.y) / 2;
        const offset = Math.sin(idx * 1.7) * 18;

        const isHighlighted = hoveredNode === a || hoveredNode === b;
        const baseAlpha = isHighlighted ? 0.35 : 0.1;

        ctx.beginPath();
        ctx.moveTo(pa.x, pa.y);
        ctx.quadraticCurveTo(mx + offset, my - offset, pb.x, pb.y);
        ctx.strokeStyle = `rgba(59, 130, 246, ${baseAlpha})`;
        ctx.lineWidth = isHighlighted ? 1.5 : 0.8;
        ctx.stroke();

        const speed = 0.012 + (idx % 3) * 0.004;
        const t1 = ((time * speed + idx * 0.4) % 1);
        const t2 = ((time * speed + idx * 0.4 + 0.5) % 1);

        [t1, t2].forEach((t) => {
          const tt = 1 - t;
          const px = tt * tt * pa.x + 2 * tt * t * (mx + offset) + t * t * pb.x;
          const py = tt * tt * pa.y + 2 * tt * t * (my - offset) + t * t * pb.y;
          const alpha = Math.sin(t * Math.PI) * (isHighlighted ? 0.9 : 0.5);
          const size = isHighlighted ? 2.5 : 1.8;

          ctx.beginPath();
          ctx.arc(px, py, size, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(96, 165, 250, ${alpha})`;
          ctx.fill();
        });
      });

      nodes.forEach((n, i) => {
        const pos = getNodePos(n);
        const isHovered = hoveredNode === i;
        const isConnected = hoveredNode >= 0 && edges.some(
          ([a, b]) => (a === hoveredNode && b === i) || (b === hoveredNode && a === i)
        );
        const isDimmed = hoveredNode >= 0 && !isHovered && !isConnected && hoveredNode !== i;

        const pulse = Math.sin(time * 0.025 + i * 1.3) * 3;
        const glowR = n.r + pulse + (isHovered ? 14 : 8);

        const grd = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, glowR);
        const glowAlpha = isDimmed ? 0.02 : isHovered ? 0.2 : 0.06;
        grd.addColorStop(0, n.color + (isHovered ? '33' : '15'));
        grd.addColorStop(1, n.color + '00');
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, glowR, 0, Math.PI * 2);
        ctx.fillStyle = grd;
        ctx.fill();

        if (isHovered) {
          ctx.beginPath();
          ctx.arc(pos.x, pos.y, n.r + 4, 0, Math.PI * 2);
          ctx.strokeStyle = n.color + '44';
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        const nodeAlpha = isDimmed ? 0.25 : 1;
        ctx.globalAlpha = nodeAlpha;
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = n.color;
        ctx.fill();

        ctx.beginPath();
        ctx.arc(pos.x, pos.y - n.r * 0.3, n.r * 0.5, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.fill();

        const labelAlpha = isDimmed ? 0.15 : isHovered ? 1 : 0.65;
        ctx.globalAlpha = labelAlpha;
        ctx.font = `${isHovered ? '600' : '400'} ${isHovered ? 11 : 10}px Inter, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = '#e2e8f0';

        if (n.type === 'client') {
          ctx.font = `700 ${isHovered ? 13 : 12}px Inter, sans-serif`;
          ctx.fillStyle = '#f1f5f9';
        }

        ctx.fillText(n.label, pos.x, pos.y + n.r + (isHovered ? 18 : 16));
        ctx.globalAlpha = 1;
      });

      if (hoveredNode >= 0) {
        canvas.style.cursor = 'pointer';
      } else {
        canvas.style.cursor = 'default';
      }

      time++;
      requestAnimationFrame(draw);
    }

    draw();

    let resizeTimeout;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(resize, 200);
    });
  }

  // ---- Navbar Scroll Effect ----
  function initNavbar() {
    const navbar = document.getElementById('navbar');
    const toggle = document.getElementById('navToggle');
    const links = document.getElementById('navLinks');

    window.addEventListener('scroll', () => {
      navbar.classList.toggle('scrolled', window.scrollY > 50);
    });

    if (toggle && links) {
      toggle.addEventListener('click', () => {
        toggle.classList.toggle('active');
        links.classList.toggle('open');
      });

      links.querySelectorAll('a').forEach((a) => {
        a.addEventListener('click', () => {
          toggle.classList.remove('active');
          links.classList.remove('open');
        });
      });
    }
  }

  // ---- Scroll Reveal (enhanced with multiple animation types) ----
  function initReveal() {
    const els = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale, .reveal-blur');

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const delay = parseInt(entry.target.dataset.delay || '0', 10);
            setTimeout(() => entry.target.classList.add('visible'), delay);
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.08, rootMargin: '0px 0px -60px 0px' }
    );

    els.forEach((el) => observer.observe(el));
  }

  // ---- Counter Animation ----
  function initCounters() {
    const counters = document.querySelectorAll('.stat-number');

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;

          const el = entry.target;
          const target = parseInt(el.dataset.target, 10);
          const prefix = el.dataset.prefix || '';
          const suffix = el.dataset.suffix || '';
          const format = el.dataset.format || '';

          let current = 0;
          const duration = 2000;
          const step = target / (duration / 16);
          const start = performance.now();

          function update(now) {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 4);
            current = Math.round(target * eased);

            let display = current.toLocaleString('pt-BR');
            if (format === 'compact' && current >= 1000) {
              display = (current / 1000).toFixed(current >= 10000 ? 0 : 0) + 'k';
              display = Math.round(current / 1000) + 'k';
            }

            el.textContent = prefix + display + suffix;

            if (progress < 1) {
              requestAnimationFrame(update);
            }
          }

          requestAnimationFrame(update);
          observer.unobserve(el);
        });
      },
      { threshold: 0.5 }
    );

    counters.forEach((c) => observer.observe(c));
  }

  // ---- FAQ Accordion ----
  function initFaq() {
    document.querySelectorAll('.faq-trigger').forEach((trigger) => {
      trigger.addEventListener('click', () => {
        const item = trigger.closest('.faq-item');
        const content = item.querySelector('.faq-content');
        const isActive = item.classList.contains('active');

        document.querySelectorAll('.faq-item.active').forEach((openItem) => {
          if (openItem !== item) {
            openItem.classList.remove('active');
            openItem.querySelector('.faq-trigger').setAttribute('aria-expanded', 'false');
            openItem.querySelector('.faq-content').style.maxHeight = '0';
          }
        });

        if (isActive) {
          item.classList.remove('active');
          trigger.setAttribute('aria-expanded', 'false');
          content.style.maxHeight = '0';
        } else {
          item.classList.add('active');
          trigger.setAttribute('aria-expanded', 'true');
          content.style.maxHeight = content.scrollHeight + 'px';
        }
      });
    });
  }

  // ---- Cursor Glow ----
  function initCursorGlow() {
    const glow = document.querySelector('.cursor-glow');
    if (!glow || window.matchMedia('(max-width: 768px)').matches) return;

    let x = 0, y = 0;
    let cx = 0, cy = 0;

    document.addEventListener('mousemove', (e) => {
      x = e.clientX;
      y = e.clientY;
    });

    function animate() {
      cx += (x - cx) * 0.08;
      cy += (y - cy) * 0.08;
      glow.style.left = cx + 'px';
      glow.style.top = cy + 'px';
      requestAnimationFrame(animate);
    }

    animate();
  }

  // ---- Magnetic Buttons ----
  function initMagnetic() {
    const btns = document.querySelectorAll('.magnetic');
    if (window.matchMedia('(max-width: 768px)').matches) return;

    btns.forEach((btn) => {
      btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const dx = e.clientX - (rect.left + rect.width / 2);
        const dy = e.clientY - (rect.top + rect.height / 2);
        btn.style.transform = `translate(${dx * 0.15}px, ${dy * 0.15}px)`;
      });

      btn.addEventListener('mouseleave', () => {
        btn.style.transform = 'translate(0, 0)';
        btn.style.transition = 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)';
        setTimeout(() => { btn.style.transition = ''; }, 400);
      });
    });
  }

  // ---- Smooth Anchor Scrolling ----
  function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener('click', (e) => {
        const target = document.querySelector(anchor.getAttribute('href'));
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  }

  // ---- Form Submit ----
  function initForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const originalHTML = btn.innerHTML;
      btn.innerHTML = '<span>Enviado com sucesso! Entraremos em contato.</span>';
      btn.style.pointerEvents = 'none';
      btn.style.opacity = '0.7';

      setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.style.pointerEvents = '';
        btn.style.opacity = '';
        form.reset();
      }, 4000);
    });
  }

  // ---- Dashboard Bar Chart ----
  function initDashChart() {
    const canvas = document.getElementById('dashChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.parentElement.getBoundingClientRect();
    const w = rect.width;
    const h = 140;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const months = ['Set', 'Out', 'Nov', 'Dez', 'Jan', 'Fev'];
    const data2026 = [28, 32, 35, 38, 41, 43];
    const data2025 = [22, 24, 26, 25, 28, 30];
    const max = 50;

    let progress = 0;
    let started = false;

    function draw() {
      ctx.clearRect(0, 0, w, h);

      const barArea = w - 40;
      const groupWidth = barArea / months.length;
      const barWidth = groupWidth * 0.28;
      const gap = 4;
      const baseY = h - 20;
      const chartH = h - 35;

      ctx.fillStyle = 'rgba(255,255,255,0.3)';
      ctx.font = '10px Inter, sans-serif';
      ctx.textAlign = 'center';

      months.forEach((m, i) => {
        const x = 30 + i * groupWidth + groupWidth / 2;
        ctx.fillText(m, x, h - 4);
      });

      const gridLines = [0, 10, 20, 30, 40, 50];
      ctx.strokeStyle = 'rgba(255,255,255,0.04)';
      ctx.lineWidth = 0.5;
      gridLines.forEach((v) => {
        const y = baseY - (v / max) * chartH;
        ctx.beginPath();
        ctx.moveTo(28, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      });

      months.forEach((m, i) => {
        const cx = 30 + i * groupWidth + groupWidth / 2;
        const h2025 = (data2025[i] / max) * chartH * progress;
        const h2026 = (data2026[i] / max) * chartH * progress;

        ctx.fillStyle = 'rgba(59, 130, 246, 0.2)';
        ctx.beginPath();
        ctx.roundRect(cx - barWidth - gap / 2, baseY - h2025, barWidth, h2025, [3, 3, 0, 0]);
        ctx.fill();

        const grd = ctx.createLinearGradient(0, baseY - h2026, 0, baseY);
        grd.addColorStop(0, '#60a5fa');
        grd.addColorStop(1, '#3b82f6');
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.roundRect(cx + gap / 2, baseY - h2026, barWidth, h2026, [3, 3, 0, 0]);
        ctx.fill();
      });

      if (progress < 1) {
        progress += 0.025;
        requestAnimationFrame(draw);
      }
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started) {
            started = true;
            draw();
          }
        });
      },
      { threshold: 0.3 }
    );

    observer.observe(canvas);
  }

  // ---- WhatsApp Chat Animation ----
  function initWhatsAppChat() {
    const chat = document.getElementById('wppChat');
    if (!chat) return;

    const conversation = [
      { type: 'out', text: 'Oi, bom dia! Quebrou o vidro do meu carro 😩', time: '09:12' },
      { type: 'typing', duration: 1200 },
      { type: 'in', text: 'Bom dia, João! Sinto muito pelo vidro. Vou te ajudar a resolver isso agora. Qual é o veículo? Placa e modelo, por favor.', time: '09:12' },
      { type: 'out', text: 'Honda Civic 2023, placa ABC-1D23', time: '09:13' },
      { type: 'typing', duration: 1500 },
      { type: 'in', text: 'Encontrei sua apólice Auto Porto Seguro #12345. ✅\n\nCobertura de vidros está ativa. Pode mandar uma foto do dano?', time: '09:13' },
      { type: 'out', text: '📷 [Foto do vidro trincado]', time: '09:14' },
      { type: 'typing', duration: 2000 },
      { type: 'in', text: 'Foto recebida! Já estou abrindo o sinistro na Porto Seguro. Um momento...', time: '09:14' },
      { type: 'typing', duration: 2500 },
      { type: 'in', text: '✅ Sinistro #78432 aberto com sucesso!\n\n🔹 Protocolo: PS-2026-78432\n🔹 Previsão: reparo em até 3 dias úteis\n🔹 A Porto vai entrar em contato para agendar\n\nVou acompanhar e te aviso a cada atualização. Precisa de mais alguma coisa?', time: '09:15' },
      { type: 'out', text: 'Nossa, que rápido! Obrigado 👏', time: '09:15' },
      { type: 'typing', duration: 800 },
      { type: 'in', text: 'Imagina, João! Qualquer novidade eu aviso por aqui. Bom dia! 😊', time: '09:16' },
    ];

    let started = false;

    function now() { return ''; }

    function addMessage(msg) {
      return new Promise((resolve) => {
        if (msg.type === 'typing') {
          const typing = document.createElement('div');
          typing.className = 'wpp-typing';
          typing.innerHTML = '<span></span><span></span><span></span>';
          chat.appendChild(typing);
          chat.scrollTop = chat.scrollHeight;
          setTimeout(() => {
            typing.remove();
            resolve();
          }, msg.duration);
          return;
        }

        const el = document.createElement('div');
        const cls = msg.type === 'in' ? 'wpp-msg-in' : 'wpp-msg-out';
        el.className = `wpp-msg ${cls}`;

        const textContent = msg.text.replace(/\n/g, '<br>');
        el.innerHTML = `${textContent}<span class="wpp-time">${msg.time}</span>`;

        chat.appendChild(el);
        chat.scrollTop = chat.scrollHeight;

        setTimeout(resolve, msg.type === 'out' ? 600 : 400);
      });
    }

    async function playConversation() {
      if (started) return;
      started = true;

      for (const msg of conversation) {
        if (msg.type === 'out') {
          await new Promise((r) => setTimeout(r, 800));
        }
        await addMessage(msg);
      }

      setTimeout(() => {
        const existing = chat.querySelectorAll('.wpp-msg, .wpp-typing');
        existing.forEach((el) => el.remove());
        started = false;
      }, 6000);
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started) {
            setTimeout(playConversation, 600);
          }
        });
      },
      { threshold: 0.3 }
    );

    observer.observe(chat);
  }

  // ---- Init All ----
  document.addEventListener('DOMContentLoaded', () => {
    initConstellation();
    initMiniGraph();
    initNavbar();
    initReveal();
    initCounters();
    initFaq();
    initCursorGlow();
    initMagnetic();
    initSmoothScroll();
    initForm();
    initWhatsAppChat();
    initDashChart();
  });
})();
